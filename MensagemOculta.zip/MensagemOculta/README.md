# Codificador/Decodificador 
🔒 Mensagem Oculta! 🔒

Trabalho realizado: Mensagem oculta, módulo 2, Resília.

Do que se trata:

Página criada para codificar e decodificar mensagens.


Como utilizar:

Inserir a mensagem no campo: "Digite sua mensagem..."

Escolher qual ferramenta utilizar: Cifra de César ou Base64.

Escolher a chave e selecionar o que deseja: codificar ou decoficar.

A mensagem será exibida após clicar no botão: "Codificar Mensagem!"

## Checklist

- [x] Campo de Seleção: **Base64** ou **Cifra de César**

- [x] Radio Button: **Codificar** ou **Decodificar**

- [x] Incremento na opção de seleção **Cifra de César**

- [x] **Botão** para Codificar ou Decodificar Mensagem

## Tecnologias Utilizadas

- [ ] **HTML** 
- [ ] **CSS** 
- [ ] **JAVASCRIPT**

## Demo

